Pitchable for Windows - test version (November 1, 2026)

This is a test version. It hasn't run on a real Windows computer yet, and it isn't code-signed.
Version française : LISEZMOI.txt

START
1. Extract the zip: right-click it, then "Extract All".
2. Optional, before you open it: check the files (CHECK THE FILES, just below).
3. Double-click Pitchable.exe in the Pitchable folder.
4. Windows SmartScreen may say it protected your PC: choose "More info", then "Run anyway".
5. Pitchable uses Microsoft Edge WebView2, already on up-to-date Windows 10 and 11.

CHECK THE FILES (OPTIONAL, BEFORE YOU OPEN PITCHABLE.EXE)
Compare them with SHA256SUMS.txt on the website, never with anything in this zip: a changed zip could
carry a changed readme too.
- The reference: https://docodo10.github.io/radiuspilot-site/files/SHA256SUMS.txt
- In a Command Prompt, in the folder where you saved the zip:
    certutil -hashfile Pitchable-windows-test.zip SHA256
  Then in the Pitchable folder:
    certutil -hashfile Pitchable.exe SHA256
- Each time, the line of 64 letters and digits it prints should be the one in front of that file's
  name in SHA256SUMS.txt. If it isn't, don't open the file.

SIGN IN
- Create your account on this PC, or look around first: the prefilled account opens the demo workspace,
  and any password of 6 characters or more works. The "Built-in authenticator" box shows the 6-digit code.

GOOD TO KNOW
- The demo workspace is separate from your own: every business, number and message in it is invented,
  and its example.com addresses can't receive email.
- Real scans list real businesses from public map listings, free and with no API key. Ratings and
  reviews aren't included. The data credit is in Settings > About.
- Emails are simulated until you connect your own mailbox in Settings > Email. Every outreach email
  carries an unsubscribe line.
- Your workspaces are saved on this PC, under %LOCALAPPDATA%\Pitchable, encrypted by Windows for your
  Windows account. To move them to another PC, use a backup (protected with a password) from
  Settings > Data: the files themselves only open for you, on this PC.

AI (OPTIONAL)
Pitchable can write with your own AI account, in Settings > AI:
- Codex on this PC: install it (with Node.js: npm install -g @openai/codex), run "codex login" in a
  terminal, then choose "Check again" in Settings > AI.
- Or "Continue with ChatGPT", or an OpenAI API key.
Everything the AI writes is labelled "AI-generated", and nothing is sent without you. Without an AI
account, Pitchable uses its own templates.
