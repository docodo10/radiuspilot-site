RadiusPilot for Windows - test version (October 27, 2026)

This is a test version. It hasn't run on a real Windows computer yet, and it isn't code-signed.
Version française : LISEZMOI.txt

START
1. Extract the zip: right-click it, then "Extract All".
2. Double-click RadiusPilot.exe in the RadiusPilot folder.
3. Windows SmartScreen may say it protected your PC: choose "More info", then "Run anyway".
4. RadiusPilot uses Microsoft Edge WebView2, already on up-to-date Windows 10 and 11.

SIGN IN
- Create your account on this PC, or look around first: the prefilled account opens the demo workspace,
  and any password of 6 characters or more works. The "Built-in authenticator" box shows the 6-digit code.

GOOD TO KNOW
- The demo workspace is separate from your own: every business, number and message in it is invented,
  and its example.com addresses can't receive email.
- Real scans list real businesses from public map listings, free and with no API key. Ratings and
  reviews aren't included. The data credit is in Settings > About.
- Emails are simulated until you connect your own mailbox in Settings > Email. Every outreach email
  carries an unsubscribe line.
- Your workspaces are saved on this PC, under %LOCALAPPDATA%\RadiusPilot. Back them up in Settings > Data.

AI (OPTIONAL)
RadiusPilot can write with your own AI account, in Settings > AI:
- Codex on this PC: install it (with Node.js: npm install -g @openai/codex), run "codex login" in a
  terminal, then choose "Check again" in Settings > AI.
- Or "Continue with ChatGPT", or an OpenAI API key.
Everything the AI writes is labelled "AI-generated", and nothing is sent without you. Without an AI
account, RadiusPilot uses its own templates.
